#include <stdio.h>

int main(){

printf("Sizes of Data Types on Current Machine\n");
printf("int:            - %lu bytes\n", sizeof(int));
printf("short:          - %lu bytes\n", sizeof(short));
printf("long:           - %lu bytes\n", sizeof(long));
printf("long long:      - %lu bytes\n", sizeof(long long));
printf("unsigned int:   - %lu bytes\n", sizeof(unsigned int));
printf("char:           - %lu bytes\n", sizeof(char));
printf("float:          - %lu bytes\n", sizeof(float));
printf("double:         - %lu bytes\n", sizeof(double));
printf("long double:    - %lu bytes\n", sizeof(long double));





return 0;
}

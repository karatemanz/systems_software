Pitt ID: adz13
The session number is a randomly generated 10 digit integer value.
The first number is the sum of even numbers in session no.
The second number is the sum of all numbers in session no.
The third number is the second # multiplied by the 2 to the power of the fourth # (or the 2nd# << 4th#).
The fourth number is less than the 1st number
The fifth number is less than 10th(last) number
(the positions specified our based on the session number)

Session Number: 4668442615
Number 1 is (4+6+6+8+4+4+2+6) = 40
Number 2 is (40 + 1 + 5) = 46
Number 3 is (6 * 2^8) = 1536		*or 6 << 8
Number 4 is (# < 4) 2
Number 5 is (# < 5) 4
